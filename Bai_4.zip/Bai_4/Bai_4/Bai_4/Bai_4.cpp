#define _crt_secure_no_deprecate
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct SinhVien {
	char hoTen[20];
	char maSV[10];
	float diem[5];
};
void nhap(SinhVien& sv) {
	printf("Nhap ten: ");
	fflush(stdin);
	fgets(sv.hoTen, 20, stdin);
	printf("Nhap ma so: ");
	fgets(sv.maSV, 10, stdin);
	for (int i = 0; i < 5; i++) {
		printf("Mon %d: ", i + 1);
		scanf_s("%f", &sv.diem[i]);
	}
	getchar();
}
void xuat(SinhVien sv) {
	printf("\nHo va ten sinh vien: \n");
	printf("%s", sv.hoTen);
	printf("Ma so sinh vien: \n");
	printf("%s", sv.maSV);
	printf("Diem 5 mon: \n");
	for (int i = 0; i < 5; i++) {
		printf("Mon %d: \n", i + 1);
		printf("%f\n", sv.diem[i]);
	}
}
SinhVien TaoSV() {
	SinhVien sv;
	nhap(sv);
	return sv;
}
struct Node {
	SinhVien data;
	struct Node* prev;
	struct Node* next;
};
Node* makeNode(SinhVien x) {
	Node* newNode = new Node;
	newNode->data = x;
	newNode->next = NULL;
	newNode->prev = NULL;
	return newNode;
}
/*=======================QUICK_SORT=============================*/
void swap(SinhVien* a, SinhVien* b)
{
	SinhVien t = *a; *a = *b; *b = t;
}

// A utility function to find last node of linked list 
struct Node* lastNode(struct Node* root)
{
	while (root && root->next)
		root = root->next;
	return root;
}

/* Considers last element as pivot, places the
pivot element at its correct position in sorted array,
and places all smaller (smaller than pivot) to left
of pivot and all greater elements to right of pivot */
struct Node* partition(struct Node* l, struct Node* h)
{
	// set pivot as h element 
	SinhVien x = h->data;
	float dtbx = (x.diem[0] + x.diem[1] + x.diem[2] + x.diem[3] + x.diem[4]) / 5;
	// similar to i = l-1 for array implementation 
	struct Node* i = l->prev;

	// Similar to "for (int j = l; j <= h- 1; j++)" 
	for (struct Node* j = l; j != h; j = j->next) 
	{
		float dtb = (j->data.diem[0]+ j->data.diem[1]+ j->data.diem[2]+ j->data.diem[3]+ j->data.diem[4])/5;
		if (dtb <= dtbx)
		{
			// Similar to i++ for array 
			i = (i == NULL) ? l : i->next;

			swap(&(i->data), &(j->data));
		}
	}
	i = (i == NULL) ? l : i->next; // Similar to i++ 
	swap(&(i->data), &(h->data));
	return i;
}

/* A recursive implementation of quicksort for linked list */
void _quickSort(struct Node* l, struct Node* h)
{
	if (h != NULL && l != h && l != h->next)
	{
		struct Node* p = partition(l, h);
		_quickSort(l, p->prev);
		_quickSort(p->next, h);
	}
}

// The main function to sort a linked list. 
// It mainly calls _quickSort() 
void quickSort(struct Node* head)
{
	// Find last node 
	struct Node* h = lastNode(head);

	// Call the recursive QuickSort 
	_quickSort(head, h);
}

// A utility function to print contents of arr 
void printList(struct Node* head)
{
	while (head)
	{
		printf("%d ", head->data);
		head = head->next;
	}
	printf("\n");
}
/*=======================QUICK_SORT=============================*/
void duyet(Node* head) {
	while (head != NULL) {
		xuat(head->data);
		head = head->next;
	}
}

void ThemVaoDau(Node** head, SinhVien x) {
	Node* newNode = makeNode(x);
	newNode->next = (*head);
	if (*head != NULL)
		(*head)->prev = newNode;
	(*head) = newNode;
}
void xoaCuoi(Node** head) {
	if (*head == NULL) return; // DSLK rong
	if ((*head)->next == NULL) {
		free(*head);
		(*head) = NULL;
	}
	else {
		Node* tmp = (*head);
		while (tmp->next->next != NULL) {
			tmp = tmp->next;
		}
		Node* delNode = tmp->next;
		tmp->next = NULL;
		delete delNode;
	}
}
void checkMSSV(Node* head) {
	char mssv[10];
	printf("Nhap ma so can tim: ");
	fgets(mssv, 10, stdin);
	int flag = 0;
	while (head != NULL) {
		if (strcmp(mssv, head->data.maSV) == 0)
			xuat(head->data);
				flag = 1;
		head = head->next;
	}
	if (flag == 0)
		printf("Khong thay");
}

int main() {
	Node* head = NULL;
	SinhVien sv1, sv2, sv3;
	sv1 = TaoSV();
	sv2 = TaoSV();
	sv3 = TaoSV();
	ThemVaoDau(&head, sv1);
	ThemVaoDau(&head, sv2);
	ThemVaoDau(&head, sv3);
	quickSort(head);
	duyet(head);
}