﻿/*Đề 8: Cài đặt :
1. Cài đặt stack dùng danh sách liên kết với phần dữ liệu là kí tự.
2. Viết hàm kiểm tra xem một chuỗi đầu vào có phải là một dãy ngoặc đúng(parentheses, brackets và braces) hay không bằng cách sử dụng stack.
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct node {
    char data;
    struct node* next;
};

typedef struct node NODE;
typedef struct node* PNODE;

struct queue {
    PNODE front, rear;
};

typedef struct queue QUEUE;

struct stack {
    PNODE top;
};

typedef struct stack STACK;

void InitQueue(QUEUE& q) {
    q.front = q.rear = NULL;
}

int IsEmptyQueue(QUEUE q) {
    return q.front == NULL;
}

void Enqueue(QUEUE& q, char x) {
    PNODE p = new NODE;
    if (p == NULL) {
        printf("Khong du bo nho!\n");
        return;
    }

    p->data = x;
    p->next = NULL;

    if (IsEmptyQueue(q)) {
        q.front = q.rear = p;
    }
    else {
        q.rear->next = p;
        q.rear = p;
    }
}

char Dequeue(QUEUE& q) {
    if (IsEmptyQueue(q)) {
        printf("Queue rong!\n");
        return '\0'; // Or any special value to indicate error
    }

    PNODE temp = q.front;
    char x = temp->data;
    q.front = q.front->next;

    if (q.front == NULL) {
        q.rear = NULL;
    }

    delete temp;
    return x;
}

void InitStack(STACK& s) {
    s.top = NULL;
}

int IsEmptyStack(STACK s) {
    return s.top == NULL;
}

void Push(STACK& s, char x) {
    PNODE p = new NODE;
    if (p == NULL) {
        printf("Khong du bo nho!\n");
        return;
    }

    p->data = x;
    p->next = s.top;
    s.top = p;
}

char Pop(STACK& s) {
    if (IsEmptyStack(s)) {
        printf("Stack rong!\n");
        return '\0'; // Or any special value to indicate error
    }

    PNODE temp = s.top;
    char x = temp->data;
    s.top = s.top->next;
    delete temp;
    return x;
}
char Top(STACK s) {
    return s.top->data;
}
/*-------------------Đề 8-----------------------*/
bool check(char s[]) {
    bool ok = false;
    STACK stk;
    InitStack(stk);
    for (int i = 0; i < strlen(s); i++) {
        if (s[i] == '}' && !IsEmptyStack(stk) && Top(stk) == '{') Pop(stk);
        else if (s[i] == ']' && !IsEmptyStack(stk) && Top(stk) == '[') Pop(stk);
        else if (s[i] == ')' && !IsEmptyStack(stk) && Top(stk) == '(') Pop(stk);
        else Push(stk, s[i]);
    }
    if (IsEmptyStack(stk)) ok = true;

    return ok;
}
void kiemtrangoac(char s[]) {
    bool ok = check(s);
    if (ok) printf("TRUE");
    else printf("FALSE");
}
/*-------------------Đề 9-----------------------*/
int CheckPalindrome(char str[]) {
    QUEUE q;
    STACK s;
    InitQueue(q);
    InitStack(s);

    int i = 0;
    while (str[i] != '\0') {
        Enqueue(q, str[i]);
        Push(s, str[i]);
        i++;
    }

    i = 0;
    while (!IsEmptyQueue(q) && !IsEmptyStack(s)) {
        if (Dequeue(q) != Pop(s)) {
            return 0;
        }
        i++;
    }

    return 1;
}

int main() {
    char string1[] = "{[()]}";
    char string2[] = "(()){{}";
    char string3[] = "))))";
    char string4[] = "({[()]})";
    char string5[] = "radar";
    char string6[] = "abcded";
    kiemtrangoac(string4);


    int isPalindrome = CheckPalindrome(string5);
    if (isPalindrome) {
        printf("\n%s la chuoi palindrome\n", string5);
    }
    else {
        printf("\n%s khong la chuoi palindrome\n", string5);
    }

    return 0;
}